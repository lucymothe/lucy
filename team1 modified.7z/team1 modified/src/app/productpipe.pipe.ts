import { Pipe, PipeTransform } from '@angular/core';
import { Product } from 'src/app/service';

@Pipe({
  name: 'productpipe'
})
export class ProductpipePipe implements PipeTransform {

  transform(products : Product[], searchterm:String) {
    if(!products || !searchterm){
      return products;
    }
    
  }

}
