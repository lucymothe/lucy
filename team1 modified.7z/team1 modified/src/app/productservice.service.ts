import { Injectable } from '@angular/core';
import { Product } from 'src/app/service';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  private listproducts: Product[] = [{
    id : 1,
    name:"Laptop",
    ItemName:"Dell Laptop",
    price:36000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/laptop.jpg',
    isActive:true

  },{
    id : 2,
    name:"Laptops",
    ItemName:"Dell Laptop",
    price:38000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/image.jpg',
    isActive:true



  },{
    id : 3,
    name:"Laptop",
    ItemName:"Apple Laptop",
    price:50000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/apple.jpg',
    isActive:true

  },{
    id : 4,
    name:"Laptop",
    ItemName:"Hp Laptop",
    price:40000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/HP.png',
    isActive:true
  },
  {
    id : 5,
    name:"Mobiles",
    ItemName:"Redmi",
    price:18000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/mi.jpg',
    isActive:true
  },
  {
    id : 6,
    name:"Mobile",
    ItemName:"OnePlus",
    price:16000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/oneplus.jpg',
    isActive:true
  },
  {
    id : 7,
    name:"Mobile",
    ItemName:"Micromax",
    price:21000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/miicromax.jpg',
    isActive:true
  },
  {
    id : 8,
    name:"Mobile",
    ItemName:"vivo",
    price:26000,
    description:"Inter Core 8,Camera",
    photopath:'assets/images/vivo.jpg',
    isActive:true
  }];
  getProducts(): Product[] {
    return this.listproducts;

  }

  constructor() { }
}
