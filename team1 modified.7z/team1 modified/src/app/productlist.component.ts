import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/service';
import { ProductserviceService } from 'src/app/productservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
  products: Product[];
  filteredProducts:Product[];
  private _searchterm:string;
  get searchterm():string{
    return this._searchterm;

  }
  set searchterm(value:string){
    this._searchterm=value;
    this.filteredProducts=this.filteredProduct1(value);
  }
  filteredProduct1(searchString:string){
    return this.products.filter(product=>product.name.toLowerCase().startsWith(searchString.toLowerCase()));
  }

  

  constructor(private productservice: ProductserviceService,private router:Router) { }

  ngOnInit() {
   this.products= this.productservice.getProducts();
   this.filteredProducts=this.products;
  }
  addToCart(){
    this.router.navigate(["./productcart"]);
  }
  addToWishList(){
    this.router.navigate(["./productwishlist"]);

  }

}
