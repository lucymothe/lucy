import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { UserService } from './user.service';

@Component({
  selector: 'app-registration-page',
  templateUrl: './registration-page.component.html',
  styleUrls: ['./registration-page.component.css']
})
export class RegistrationPageComponent implements OnInit {
  model:any={};

  constructor(private userService:UserService) { }

  ngOnInit() {
  }
  addUser():any{
    console.log(this.model);
    this.userService.addUser(this.model).subscribe();
  }
 
   
  }


