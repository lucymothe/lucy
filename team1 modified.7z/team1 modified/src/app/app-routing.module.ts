import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page.component';
import { RegistrationPageComponent } from './registration-page.component';
import { ProductlistComponent } from './productlist.component';
import { ProductcartComponent } from './productcart.component';
import { ProductwishlistComponent } from './productwishlist.component';
import { ProductcheckoutComponent } from './productcheckout.component';


const routes: Routes = [
  {path:'login',component:LoginPageComponent},
  {path:'signup',component:RegistrationPageComponent},
  {path:'products',component:ProductlistComponent},
  {path:'productcart',component:ProductcartComponent},
  {path:'productwishlist',component:ProductwishlistComponent},
  {path:'productcheckout',component:ProductcheckoutComponent},
  {path:'',redirectTo:'/login',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
