import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productwishlist',
  templateUrl: './productwishlist.component.html',
  styleUrls: ['./productwishlist.component.css']
})
export class ProductwishlistComponent implements OnInit {

  constructor(private service:UserService,private router:Router) { }

  ngOnInit() {
  }
  backToCart(){
    this.router.navigate(["./productcart"])

  }

}
