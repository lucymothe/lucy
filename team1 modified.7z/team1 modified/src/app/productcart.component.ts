import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productcart',
  templateUrl: './productcart.component.html',
  styleUrls: ['./productcart.component.css']
})
export class ProductcartComponent implements OnInit {

  constructor(private service:UserService,private router:Router) { }

  ngOnInit() {
  }
  backToList(){
    this.router.navigate(["./products"]);

  }
  checkOut(){
    this.router.navigate(["./productcheckout"]);
  }

}
