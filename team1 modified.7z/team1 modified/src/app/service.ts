export class Product{
    id:number;
    name:String;
    ItemName:String;
    price:number;
    description:String;
    photopath?:String;
    isActive:boolean;
}