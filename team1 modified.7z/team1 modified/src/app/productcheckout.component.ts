import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productcheckout',
  templateUrl: './productcheckout.component.html',
  styleUrls: ['./productcheckout.component.css']
})
export class ProductcheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
