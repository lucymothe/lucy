import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClient} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductlistComponent } from './productlist.component';
import { ProductpipePipe } from './productpipe.pipe';
import { LoginPageComponent } from './login-page.component';
import { RegistrationPageComponent } from './registration-page.component';
import { ContactpageComponent } from './contactpage.component';
import { HttpClientModule } from '@angular/common/http';
import { ProductcartComponent } from './productcart.component';
import { ProductwishlistComponent } from './productwishlist.component';
import { ProductcheckoutComponent } from './productcheckout.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductlistComponent,
    ProductpipePipe,
    LoginPageComponent,
    RegistrationPageComponent,
    ContactpageComponent,
    ProductcartComponent,
    ProductwishlistComponent,
    ProductcheckoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
