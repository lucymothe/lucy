import { Injectable } from '@angular/core';
import { Router } from '../../node_modules/@angular/router';
import { User } from './user';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userDetails:User[]=[

  ];

  constructor(private http:HttpClient,private router:Router){}

  addUser(data:any){
    let input={
      "name":data.name,
      "phonenumber":data.phonenumber,
      "emailId":data.email,
      "password":data.password,
      "confirmPassword":data.confirmPassword
    }
    return this.http.post("http://localhost:9989/registration/addall",input);
  }
 
}
