import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../Product.interface';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
/*
  
*/
export class SearchFormComponent implements OnInit {
 resultProducts:Product[];
 searchterm1:any;
 searchterm2:any;
/*
  injecting the service by creating service object.
*/
  constructor(private productService:ProductService) { }
/*
  method name:ngOnInit
  purpose :retrieved the filtered data and stored it in resultProducts array of Product Interface type.
*/
  ngOnInit() {
    this.productService.getProducts().subscribe((data)=>this.resultProducts=data,(error)=>console.log(error));
  }
 
  searchProduct(){
    this.searchterm2=this.searchterm1;

    
  }

}
