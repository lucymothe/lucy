import { Injectable } from '@angular/core';
import { Product } from './Product.interface';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products: Product[];

   constructor(private httpClient: HttpClient) { }
 /* 
   method:getProducts
   purpose:to get data from json file.
 */
  getProducts(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("..//assets/db.json").pipe(catchError(this.handleError));
  }
  handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error("Client side error", errorResponse.error.message);
    } else {
      console.error("ServerSide Error", errorResponse);
    }
    return throwError("Something went wrong, please try after sometime");

  }
 
  

}
