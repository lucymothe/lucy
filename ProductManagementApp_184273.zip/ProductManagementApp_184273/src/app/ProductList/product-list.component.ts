import { Component, OnInit } from '@angular/core';
import { Product } from '../Product.interface';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})

export class ProductListComponent implements OnInit {
  products:Product[];
  constructor(private productService : ProductService) { }

  ngOnInit() {
    this.productService.getProducts().subscribe((data)=>this.products=data,(error)=>console.log(error));
  }
  /*
  method name:deleteProduct
  purpose:to delete a row from the table when delete button is clicked
*/
  deleteProduct(product){
    let index=this.products.indexOf(product);
    this.products.splice(index,1);
 
  }

}
