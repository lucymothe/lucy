import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchFormComponent } from './SearchForm/search-form.component';
import { ProductListComponent } from './ProductList/product-list.component';
import { PageNotFoundComponent } from './PageNotFound/page-not-found.component';

const routes: Routes = [
  {path:'searchform',component:SearchFormComponent},
  {path:'productlist',component:ProductListComponent},
  {path:'',redirectTo:'/searchform',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
