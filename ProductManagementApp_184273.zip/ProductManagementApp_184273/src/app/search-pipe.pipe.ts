import { Pipe, PipeTransform } from '@angular/core';
import { Product } from './Product.interface';

@Pipe({
  name: 'searchPipe'
})
/*
  pipename:searchPipe
  purpose:tocompare and filter the rows of table based on search term. 
*/
export class SearchPipePipe implements PipeTransform {

  transform(products:Product[],searchterm:any): any {
    if(!products && !searchterm){
      return products;
    }
    return products.filter(product=>product.name.toLowerCase().startsWith(searchterm.toLowerCase())
    ||product.category.toLowerCase().startsWith(searchterm.toLowerCase()));
  
  }

}
