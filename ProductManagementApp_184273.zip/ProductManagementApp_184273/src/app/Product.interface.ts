export interface Product{
    id:String;
    name:String;
    price:number;
    category:String;
}