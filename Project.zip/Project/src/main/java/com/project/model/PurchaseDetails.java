package com.project.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;

public class PurchaseDetails {
	
	@XmlAttribute
	private Integer OrderId;
	private Double TotalAmount;
	private List<Item> item;

	public PurchaseDetails() {
		super();
	}

	public PurchaseDetails(Integer orderId, Double totalAmount, List<Item> item) {
		super();
		OrderId = orderId;
		TotalAmount = totalAmount;
		this.item = item;
	}

	public Integer getOrderId() {
		return OrderId;
	}

	public void setOrderId(Integer orderId) {
		OrderId = orderId;
	}

	public Double getTotalAmount() {
		return TotalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		TotalAmount = totalAmount;
	}

	public List<Item> getItem() {
		return item;
	}

	public void setItem(List<Item> item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [OrderId=" + OrderId + ", TotalAmount=" + TotalAmount + ", item=" + item + "]";
	}

}
