package com.project.model;

public class PayModeTranscations
{
   
}
