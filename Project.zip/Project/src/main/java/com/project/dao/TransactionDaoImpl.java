package com.project.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.project.model.Delivery;
import com.project.model.Item;
import com.project.model.PurchaseDetails;

import com.project.model.Transaction;
import com.project.model.TransactionDetails;

@Repository
public class TransactionDaoImpl implements TransactionDao{
    
    
	@Autowired
	MongoTemplate mongoTemplate;
	
	List<Transaction> transactions;
	
	@Override
	public void addDetails(Transaction transaction) throws JAXBException {
		mongoTemplate.insert(transaction);	
		transactions=getAll();
		divideFiles(transactions);
		}

	@Override
	public List<Item> getOrderDetails(Integer orderId, Integer storeId) {
	List<Item> items=null;
	Query query=Query.query(Criteria.where("_id").is(storeId));
	Transaction transaction = mongoTemplate.findOne(query,Transaction.class);
	
	List<TransactionDetails> transactionDetails=transaction.getTransactionDetails();
    for (TransactionDetails transactionDetails2 : transactionDetails) {
	  PurchaseDetails purchaseDetails=transactionDetails2.getPurchaseDetails();
	
	  int od=purchaseDetails.getOrderId();
	
	 if(od==orderId) {
		 items=purchaseDetails.getItem();
		  
		}
	}
	return items;
	}

	@Override
	public boolean updateDetails(Integer orderId, Integer storeId, String status) throws JAXBException {
		boolean result=false;
		Query query=Query.query(Criteria.where("_id").is(storeId));
		Transaction transaction=mongoTemplate.findOne(query,Transaction.class);
		System.out.println(transaction);
		List<TransactionDetails> transactionDetails=transaction.getTransactionDetails();
		for (TransactionDetails transactionDetails2 : transactionDetails) {
			 PurchaseDetails purchaseDetails=transactionDetails2.getPurchaseDetails();
			 int od=purchaseDetails.getOrderId();
		     if(od==orderId) {
			Delivery delivery=transactionDetails2.getDelivery();
			delivery.setStatus(status);
			mongoTemplate.save(transaction);
			System.out.println("update  "+transaction);
          
            JAXBContext  context = JAXBContext.newInstance(Transaction.class);
			Marshaller marshaller=context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		    marshaller.marshal(transaction,new File("Store.xml"));
		    List<Transaction> transactions=new ArrayList<>();
		    transactions.add(transaction);
		    divideFiles(transactions);
     		result=true;
		}
     }
      return result;
	}

	@Override
	public List<Item> searchById(Integer orderId) 
	{
		 List<Item> items=null;
	     List<Transaction> transaction=mongoTemplate.findAll(Transaction.class);
	     for (Transaction transaction2 : transaction)
	     {
			 List<TransactionDetails> transactionDetails=transaction2.getTransactionDetails();
			 for ( TransactionDetails transactionDetail :transactionDetails ) 
			 {
			   PurchaseDetails purchaseDetail=transactionDetail.getPurchaseDetails();
				if((int)purchaseDetail.getOrderId()==orderId)
	               items=purchaseDetail.getItem();				
			 }
	     }
	   
	     return items;
	}

	@Override
	public Item searchByName(String itemName)
	{
		 List<Item> items=null;
		 Item item1 = null;
	     List<Transaction> transaction=mongoTemplate.findAll(Transaction.class);
	     for (Transaction transaction2 : transaction)
	     {
			 List<TransactionDetails> transactionDetails=transaction2.getTransactionDetails();
			 for ( TransactionDetails transactionDetail :transactionDetails ) 
			 {
			   PurchaseDetails purchaseDetail=transactionDetail.getPurchaseDetails();
			   items=purchaseDetail.getItem();
			   for (Item item:items) {
				  if(item.getItemName().equalsIgnoreCase(itemName))
					 item1=item; 
			   }
			 }
	     }
		return item1;
	}




public static void divideFiles(List<Transaction> transactions) throws JAXBException
{
	
			List<TransactionDetails> cashTransactionDetails = new ArrayList<TransactionDetails>();
			List<TransactionDetails> creditCardTransactionDetails=new ArrayList<TransactionDetails>();
			List<TransactionDetails> debitCardTransactionDetails=new ArrayList<TransactionDetails>();
			
			Transaction transaction1 = new Transaction();
			Transaction transaction2 = new Transaction();
			Transaction transaction3 = new Transaction();
			
			List<TransactionDetails> cashTransaction = new ArrayList<TransactionDetails>();
			List<TransactionDetails> creditCardTransaction=new ArrayList<TransactionDetails>();
			List<TransactionDetails> debitCardTransaction=new ArrayList<TransactionDetails>();
			 
			 
			 for (Transaction transaction : transactions) {
				
			 transaction1.setStoreId(transaction.getStoreId());
		     transaction2.setStoreId(transaction.getStoreId());
			 transaction3.setStoreId(transaction.getStoreId());
			 List<TransactionDetails> tDetails=transaction.getTransactionDetails();
			
			  for (TransactionDetails transactionDetails : tDetails) {
			    if(transactionDetails.getPaymentMode().equalsIgnoreCase("Cash")) {
					cashTransactionDetails.add(transactionDetails);
					 
				}else if(transactionDetails.getPaymentMode().equalsIgnoreCase("Debit")) {
					debitCardTransactionDetails.add(transactionDetails);
					
				}else{
					creditCardTransactionDetails.add(transactionDetails);
				}
			
			  

			  
			 }
			 if(!cashTransactionDetails.isEmpty()) {
				  transaction1.setTransactionDetails(cashTransactionDetails);  
				  
				 }
					if(!creditCardTransactionDetails.isEmpty()) {
						transaction2.setTransactionDetails(creditCardTransactionDetails);
						 
					}
					if(!debitCardTransactionDetails.isEmpty()) {
						transaction3.setTransactionDetails(debitCardTransactionDetails);
						 
					}
					
			 }

			   JAXBContext  context = JAXBContext.newInstance(Transaction.class);
				Marshaller marshaller=context.createMarshaller();
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				if(transaction1!=null) {
				    
					
			    marshaller.marshal(transaction1,new File("cashTransaction.xml"));}
				if(transaction2!=null) {
					
					marshaller.marshal(transaction2,new File("creditCardTransaction.xml"));
				}
				if(transaction3!=null) {
					
			    marshaller.marshal(transaction3,new File("debitCardTransaction.xml"));
				}
}

@Override
public List<Transaction> getAll() {

	return mongoTemplate.findAll(Transaction.class);
}
}
