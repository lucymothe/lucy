import { Injectable } from '@angular/core';
import { IAdmin } from './add.interface';
import {HttpClient} from '@angular/common/http';
//import { getAllLifecycleHooks } from '../../node_modules/@angular/compiler/src/lifecycle_reflector';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddService {
admin:IAdmin[]=[];
  constructor(private http:HttpClient) {   }
    getAdmin():Observable<IAdmin[]>
    {
       return this.http.get<IAdmin[]>('../assets/db.json');
      
    }
      
    get()
    {
     return this.admin;
    }


  update(){

  }
  delete()
  {
    
  }

  
}
