import { Component, OnInit } from '@angular/core';
import { AddService } from '../add.service';
import { IAdmin } from '../add.interface';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
admin:IAdmin[];
  constructor(private addservice:AddService) { }

  ngOnInit() {
    this.addservice.getAdmin().subscribe(data=>{this.admin=data});
    let a=this.addservice.get();
    for(let add of a)
    {
      this.admin.push(add);
    }
  }

}
