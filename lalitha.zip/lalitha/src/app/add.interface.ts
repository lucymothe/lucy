export interface IAdmin{
    id:number;
    name:string
}
