package com.cg.service;

import java.util.List;

import com.cg.dto.Employee;

public interface IEmployeeService  {
	public List<Employee> showAllEmployees();
	public Employee addEmployee(Employee emp);
	public Employee searchByEmployeeId(Integer empId);
	public void deleteEmployee(Integer empId);
	public Employee updateEmployee(Employee emp);


}
