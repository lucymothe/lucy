package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeRepository;
import com.cg.dto.Employee;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
    private EmployeeRepository employeeRepository;
	@Override
	public List<Employee> showAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		return employeeRepository.save(emp);
	}

	@Override
	public Employee searchByEmployeeId(Integer empId) {
		 
		return employeeRepository.findById(empId).get();
	}

	@Override
	public void deleteEmployee(Integer empId) {
		// TODO Auto-generated method stub
		employeeRepository.deleteById(empId);
		
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

}
