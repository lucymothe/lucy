import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { PageNotFoundComponent } from './employee/page-not-found.component';

const routes: Routes = [
  {path:"list",component:EmployeeListComponent},
  {path:"create",component:CreateEmployeeComponent},
  {path:"",redirectTo:"/list",pathMatch:"full"},
  {path:"**",component:PageNotFoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
