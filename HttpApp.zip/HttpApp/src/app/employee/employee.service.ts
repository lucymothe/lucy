import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { IEmployee } from './employee.interface';
import { Observable, throwError } from '../../../node_modules/rxjs';
import {catchError} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  getEmployees():Observable<IEmployee[]>{
    return this.http.get<IEmployee[]>("http://localhost:3000/employees").pipe(catchError(this.handleError));
  }

  constructor(private http:HttpClient) { }

  handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error("Client side error",errorResponse.error.message)
    }else{
      console.error("ServerSide Error",errorResponse);
    }
    return throwError("Something went wrong, please try after sometime");
  }

}
