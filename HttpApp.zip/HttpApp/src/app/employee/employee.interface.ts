export interface IEmployee{
    code:string;
    name:string;
    gender:string;
    annualSalary:number;
    dateOfBirth:string;
}