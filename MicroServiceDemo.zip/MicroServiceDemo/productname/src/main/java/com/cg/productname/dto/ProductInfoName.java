package com.cg.productname.dto;

/**
 * @author lmothe
 *
 */
public class ProductInfoName {

	
	private Integer productId;
	private String productName;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public ProductInfoName(Integer productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}
	public ProductInfoName() {
		
	}
	@Override
	public String toString() {
		return "ProductInfoName [productId=" + productId + ", productName=" + productName + "]";
	}

}
