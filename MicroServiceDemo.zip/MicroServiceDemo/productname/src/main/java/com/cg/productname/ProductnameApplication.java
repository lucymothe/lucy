package com.cg.productname;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan("com.cg.productname")
@SpringBootApplication
public class ProductnameApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductnameApplication.class, args);
	}

}
