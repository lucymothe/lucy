package com.cg.productorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.cg.productorder")
@SpringBootApplication
public class ProductorderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductorderApplication.class, args);
	}

}
