package com.cg.productorder.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productorder.dto.ProductInfoOrder;

@RestController
@RequestMapping("/productOrder")
public class ProductOrderInfoController {
	@GetMapping("/order")
	public ProductInfoOrder getProductPrice(@RequestParam("pid") Integer productId) {
		return new ProductInfoOrder(productId,77777.34);
		
	}

}
