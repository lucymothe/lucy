package com.cg.productservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.productservice.dto.ProductName;
import com.cg.productservice.dto.ProductOrder;
import com.cg.productservice.dto.ProductService;

@RestController
@RequestMapping("/allService")
public class ProductServiceController {
   @Autowired
	RestTemplate resttemplate;
   
   @GetMapping("/all")
   public ProductService getAll() {

	  ProductName productName = resttemplate.getForObject("http://localhost:9091/productName/name?pid=1001",ProductName.class);
	  ProductOrder productOrder = resttemplate.getForObject("http://localhost:9092/productOrder/order?pid=1001",ProductOrder.class);
	   return new ProductService(1001,productName.getProductName(),productOrder.getProductPrice());
   }
	
	
}