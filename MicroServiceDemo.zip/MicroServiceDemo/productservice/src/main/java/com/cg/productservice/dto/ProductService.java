package com.cg.productservice.dto;

public class ProductService {
	
	private Integer productId;
	private String productName;
	private Double ProductPrice;
	

	public Integer getProductId() {
		return productId;
	}


	public void setProductId(Integer productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public Double getProductPrice() {
		return ProductPrice;
	}


	public void setProductPrice(Double productPrice) {
		ProductPrice = productPrice;
	}


	public ProductService(Integer productId, String productName, Double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		ProductPrice = productPrice;
	}


	@Override
	public String toString() {
		return "ProductService [productId=" + productId + ", productName=" + productName + ", ProductPrice="
				+ ProductPrice + "]";
	}


	public ProductService() {
		// TODO Auto-generated constructor stub
	}

}
