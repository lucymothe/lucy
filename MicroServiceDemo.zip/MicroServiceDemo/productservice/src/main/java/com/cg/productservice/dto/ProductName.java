package com.cg.productservice.dto;

public class ProductName {
	
	private Integer productId;
	private String productName;
	
	public Integer getProductId() {
		return productId;
	}


	public void setProductId(Integer productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public ProductName() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ProductName [productId=" + productId + ", productName=" + productName + "]";
	}


	public ProductName(Integer productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}
	

}
