import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GiftsService } from 'src/app/gifts.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user:any={}
  registerForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  constructor(private formBuilder:FormBuilder, private router:Router, private service:GiftsService) { }

  ngOnInit() {
    this. registerForm = this.formBuilder.group({
      firstName:['',[Validators.required,Validators.pattern]],
      lastName:['',[Validators.required,Validators.pattern]],
      emailId: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required],
      phoneNumber:['',[Validators.required,Validators.pattern]],
  })
  }
  register(){
    this.service.register(this.user).subscribe((data:any)=>{
       if(data==1)
       alert("submitted successfully")
       this.router.navigate(['login']);
    })
  }
  // onSubmit() {
     
  //   this.submitted = true;
  //   if(this.registerForm.invalid){
  //     return;
  //   }
    
    //let username = this.registerForm.controls.email.value;
    //let password = this.registerForm.controls.password.value;

    // if(username == "admin@gmail.com" && password == "123456")
    // {
    //   localStorage.setItem("username",username);
    //   this.router.navigate(['add-movie']);
    //   alert('Login Successfully Done')
    // }
    // else{
    
    //   this.invalidLogin = true;
    //   alert("Invalid Login")
    // }
  }

