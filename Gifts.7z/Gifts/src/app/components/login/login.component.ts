import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GiftsService } from 'src/app/gifts.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  user:any={};

  constructor(private formBuilder:FormBuilder, private router:Router, private service:GiftsService) { }

  ngOnInit() {
    this. loginForm = this.formBuilder.group({
      emailId: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required]

    });
  }

  onSubmit() {
    this.service.loginValidation(this.user.emailId,this.user.password).subscribe((data)=>{
      if(data==1)
      alert("login success")
      else
      alert("Incorrect details")
      this.router.navigate(['home']);
      
    })
     
  //   this.submitted = true;
  //   if(this.loginForm.invalid){
  //     return;
  //   }

  //   let username = this.loginForm.controls.emailId.value;
  //   let password = this.loginForm.controls.password.value;

  //   if(username == "user.emailId" && password == "user.password")
  //   { 
  //     localStorage.setItem("username",username);
  //     this.router.navigate(['home']);
  //     alert('Login Successfully Done')
  //   }
  //   else{
    
  //     this.invalidLogin = true;
  //     alert("Invalid Login")
  //   }
   }
}
