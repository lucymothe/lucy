import { Component, OnInit } from '@angular/core';
import { GiftsService } from 'src/app/gifts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  

  constructor(private service:GiftsService,private router:Router) { }

  ngOnInit() {
  }
  openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
 closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
// select(){
//   this.service.category="frames";
//   this.router.navigate(['./frames'])
// }

}
