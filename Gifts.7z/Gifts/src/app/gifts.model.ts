export interface IGift{
    image:String,
    giftName:String,
    giftPrice:number,
    category:String
}
export interface IUser{
    firstName:String,
    lastName:String,
    emailId:String,
    password:String,
    phoneNumber:number
}