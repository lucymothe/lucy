import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { IUser } from './gifts.model';

@Injectable({
    providedIn: 'root'
  })
  export class GiftsService {
      users:IUser
  category: string;
      constructor(private http:HttpClient){ }
      register(users:any){
          let input={
              "firstName":users.firstName,
              "lastName":users.lastName,
              "password":users.password,
               "emailId":users.emailId,
               "phoneNumber":users.phoneNumber
          }
          console.log(input)
          return this.http.post("http://localhost:9000/addUser", input);
      
    }
   
      getAllGifts(){
          return this.http.get("http://localhost:9000/getAllGifts")
      }
      getbycategory(category:string){
          return this.http.get("http://localhost:9000/getByCategory?category="+category);
      }
      
      loginValidation(emailId,password){
          return this.http.get("http://localhost:9000/loginValidation?emailId="+emailId+"&password="+password);
      }
  }  