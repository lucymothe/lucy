import { Component, OnInit } from '@angular/core';
import { GiftsService } from 'src/app/gifts.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-frames',
  templateUrl: './frames.component.html',
  styleUrls: ['./frames.component.css']
})
export class FramesComponent implements OnInit {
gifts:any=[];
category:string;
  constructor(private service:GiftsService,private route:ActivatedRoute) {
    this.route.params.subscribe(params => this.category = params['category']);
   }

  ngOnInit() {
    this.service.getbycategory(this.category).subscribe((data:any)=>{
      this.gifts=data;
      console.log(this.gifts);
    })
  }

}
