import{Component,OnInit} from '@angular/core';
import { EmployeeService } from './app.employeeservice';
@Component({
    selector:'show-app',
    templateUrl:'app.show.html'
})
export class ShowComponent implements OnInit{
    empdata:any[]=[];  //to store the data from the dat
    constructor(private service:EmployeeService){

    }
    ngOnInit(){
         this.service.getAllEmployees().subscribe((data:any)=>this.empdata=data);
    }

}