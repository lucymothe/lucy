import { Injectable } from "../../node_modules/@angular/core";
import { HttpClient } from "../../node_modules/@angular/common/http";
import { AddEmployeeComponent } from "./app.addemployee";

@Injectable({
    providedIn:'root'
})
export class EmployeeService{
    constructor(private http:HttpClient){

    }
    getAllEmployees(){
       return  this.http.get("http://localhost:1234/emplist/getAllData");
        }
        
    // Model Attribute i.e. form data


        // addEmployee(data:any) {
        //     let input=new FormData();
        //     input.append("empId",data.eid);
        //     input.append("empName",data.ename);
        //     input.append("empSalary",data.esalary);

        //     return this.http.post("http://localhost:1234/emplist/addData",input);
        // }

        addEmployee(data:any){
            let input={"empId":data.eid,"empName":data.ename,"empSalary":data.esalary};
            return this.http.post("http://localhost:1234/emplist/addData",input);
        }
       
    }
  
