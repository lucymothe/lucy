import { OnInit, Component } from "../../node_modules/@angular/core";
import { EmployeeService } from "./app.employeeservice";

@Component({
    selector:'add-emp',
    templateUrl:'app.addemployee.html'
})
export class AddEmployeeComponent {
  model:any={}; 
    
    constructor(private service:EmployeeService){

    }
    addEmployee():any{
        console.log(this.model);
       this.service.addEmployee(this.model).subscribe();
    }
   

}