package com.example.service;

import java.util.List;

import com.example.bean.Session;
import com.example.exception.SessionException;

public interface ISessionService {

	List<Session> createSession(Session session) throws SessionException;

	List<Session> getAllSessions();

	Session updateSession(Integer sessionId, String facultyName, Double durationOfSession) throws SessionException;

	void deleteSession(Integer sessionId);

}
