package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bean.Session;
import com.example.dao.ISessionRepository;
import com.example.exception.ExceptionMessage;
import com.example.exception.SessionException;
@Service
public class SessionServiceImpl implements ISessionService {

	@Autowired
	private ISessionRepository repository;
	/*
	 * method: createSession
	 * purpose:It adds the session object to the database table named Session
	 * arguments: Session object that contains session data
	 * returns :list of all session records present in the table
	 */
	@Override
	public List<Session> createSession(Session session) throws SessionException {
		try {
			if(session.getDurationOfSession()>3 && (session.getModeOfSession().equals("ILT")||(session.getModeOfSession().equals("VC")))) {
			   repository.save(session);
			}else {
				throw new SessionException(ExceptionMessage.MESSAGE4);
			}
			}catch(Exception e) {
				throw new SessionException(ExceptionMessage.MESSAGE1);
			}
		return  repository.findAll();
	}

	/*
	 * method:getAllSessions
	 * purpose:It returns all the session records from the table
	 * return type:list 
	 */
	@Override
	public List<Session> getAllSessions() {
		return  repository.findAll();
	}
	
	/*
	 * method:updateSession
	 * purpose:It returns all the session records from the table
	 * return type:list 
	 */
    @Override
	public Session updateSession(Integer sessionId, String facultyName, Double durationOfSession) throws SessionException
	{
		try {
		    if(durationOfSession>3) {
			Session session=repository.findById(sessionId).get();
		    session.setFacultyName(facultyName);
		    session.setDurationOfSession(durationOfSession);
		    Session session1=repository.save(session);
			return session1;
		    }else {
		    	throw new SessionException(ExceptionMessage.MESSAGE3); 
		    }
		
		}catch(Exception e) {
			throw new SessionException(ExceptionMessage.MESSAGE2);
			
		}
		
	}
	
	/*
	 * method:deleteSession
	 * purpose:It deletes the session record based on the session id
	 * return type: none 
	 */
	@Override
	public void deleteSession(Integer sessionId) {
		repository.deleteById(sessionId);
	}
}
