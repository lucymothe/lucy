package com.example.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.Session;
import com.example.exception.SessionException;
import com.example.service.ISessionService;

/* 
 *class name: SessionController
 *purpose:It acts as a rest control that handles the requests from the client and forward them to 
 *        the service with appropriate mapping.
 */


@RestController
public class SessionController {
	
	@Autowired
	private ISessionService sessionService;
 
	/*
	 * This method accepts only POST request in order to insert data into session
	 */
	@RequestMapping(value = "/createSession", method = RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException, com.example.exception.SessionException {
		return  sessionService.createSession(session);
	}
	/*
	 * This method accepts only GET request in order to get all session details
	 */
	@RequestMapping(value = "/getAllSessions", method = RequestMethod.GET)
	public List<Session> getAllSessions() {
		return  sessionService.getAllSessions();
	}
	/*
	 * This method only accepts the PUT request with appropriate pattern as mentioned
	 */
	@RequestMapping(value = "/updateSession/{sessionId}/{facultyName}/{duration}", method = RequestMethod.PUT)
	public Session updateSession(@PathVariable("sessionId") Integer sessionId,@PathVariable("facultyName") String facultyName,@PathVariable("duration")Double durationOfSession) throws com.example.exception.SessionException {
		return  sessionService.updateSession(sessionId,facultyName,durationOfSession);
	}
	
	/*
	 * this method accepts the DELETE request.
	 */
	
	@RequestMapping(value = "/deleteSession/{sessionId}", method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("sessionId") Integer sessionId) {
		sessionService.deleteSession(sessionId);
		return  "sesssion of  id "+sessionId+" is deleted";
	}
	
}
