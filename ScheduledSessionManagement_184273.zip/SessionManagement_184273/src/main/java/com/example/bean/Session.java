package com.example.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Session {
	@Id
	@GeneratedValue 
	private Integer sessionId;
	private String sessionName;
	private String facultyName;
	private Double durationOfSession;
	private String modeOfSession;
	public Integer getSessionId() {
		return sessionId;
	}
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public String getFacultyName() {
		return facultyName;
	}
	
	public Double getDurationOfSession() {
		return durationOfSession;
	}
	public void setDurationOfSession(Double durationOfSession) {
		this.durationOfSession = durationOfSession;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	
	public String getModeOfSession() {
		return modeOfSession;
	}
	public void setModeOfSession(String modeOfSession) {
		this.modeOfSession = modeOfSession;
	}
	

}
