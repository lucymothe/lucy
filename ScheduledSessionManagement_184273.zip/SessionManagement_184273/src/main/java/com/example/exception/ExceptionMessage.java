package com.example.exception;

public interface ExceptionMessage {

	String MESSAGE1 = "valid details are not passed..!!";
	String MESSAGE2 = "Data not found to update..!!";
	String MESSAGE3 =" Duration of session should not be less than 3";
	String MESSAGE4 = "Please check the details properly before inserting";

}
