import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from 'src/app/search.component';
import { UpdateComponent } from 'src/app/update.component';

const routes: Routes = [
 
  {path:'search',component:SearchComponent},
  {path:'update',component:UpdateComponent},
  {path:'',redirectTo:'/search',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
