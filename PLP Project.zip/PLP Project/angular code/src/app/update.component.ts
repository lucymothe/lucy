import { Component, OnInit } from '@angular/core';
import { SearchService } from 'src/app/search.service';
import { HttpClient } from '../../node_modules/@angular/common/http';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  orderId:number;
  storeId:number;
  status:string;
  res:boolean;
  constructor(private service:SearchService,private http:HttpClient) { }

  ngOnInit() 
  {}
  
  update()
  {
     this.service.update(this.orderId,this.storeId,this.status).subscribe((data:boolean)=>{
       this.res=data;
       if(this.res==true)
         alert("updated sucessfully");
      else
         alert("Not Updated");
     });
     
  }
}
