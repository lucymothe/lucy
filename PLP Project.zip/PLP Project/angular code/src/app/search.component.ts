import { Component, OnInit } from '@angular/core';
import { SearchService } from 'src/app/search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchKey:any;
  resultSet;
  result;
  constructor(private service:SearchService ) { }

  ngOnInit() {
  }
   
  search()
  {
     if(this.searchKey>0)
     {
     
       this.service.searchById(this.searchKey).subscribe((data)=>{this.resultSet=data;});
     }
     else{
       this.service.searchByName(this.searchKey).subscribe((data)=>this.result=data);
     }
  }

}
