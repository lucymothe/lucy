import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SearchService 
{

  constructor(private http:HttpClient) { }

  searchById(term)
  {
    console.log(term);
    return this.http.get("http://localhost:9066/getbyid?orderId="+term);
  }

  searchByName(term)
  {
    return this.http.get("http://localhost:9066/getbyName?itemName="+term);
  }

  update(orderId,storeId,status)
  {
    return this.http.put("http://localhost:9066/updateDetails?orderId="+orderId+"&storeId="+storeId+"&status="+status,orderId);
  }
}
