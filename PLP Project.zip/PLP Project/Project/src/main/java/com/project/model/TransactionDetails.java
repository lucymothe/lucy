package com.project.model;



public class TransactionDetails 
{
    private String date;
    private PurchaseDetails purchaseDetails;
    private String paymentMode;
    private Delivery delivery;
	
    public TransactionDetails() {
	}

	public TransactionDetails(String date, PurchaseDetails purchaseDetails, String paymentMode, Delivery delivery) {
		
		this.date = date;
		this.purchaseDetails = purchaseDetails;
		this.paymentMode = paymentMode;
		this.delivery = delivery;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public PurchaseDetails getPurchaseDetails() {
		return purchaseDetails;
	}

	public void setPurchaseDetails(PurchaseDetails purchaseDetails) {
		this.purchaseDetails = purchaseDetails;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Delivery getDelivery() {
		return delivery;
	}

	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}

	
    
}
