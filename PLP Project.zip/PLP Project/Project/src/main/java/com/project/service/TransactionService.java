package com.project.service;

import java.util.List;

import javax.xml.bind.JAXBException;

import com.project.model.Item;

import com.project.model.Transaction;

public interface TransactionService 
{



	List<Item> getOrderDetails(Integer orderId, Integer storeId);

	boolean updateDetails(Integer orderId, Integer storeId,String status) throws JAXBException;

	List<Item> searchById(Integer orderId);

	Item searchByname(String itemName);

	  List<Transaction> getAll();
	void addDetails(Transaction transaction) throws JAXBException;

}
