package com.project.service;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.TransactionDao;
import com.project.model.Item;
import com.project.model.Store;
import com.project.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService{

	@Autowired
	private TransactionDao repo;
	
	@Override
	public void addDetails(Transaction transaction) throws JAXBException {
        repo.addDetails(transaction);		
	}

	@Override
	public List<Item> getOrderDetails(Integer orderId, Integer storeId) {
		
		return repo.getOrderDetails(orderId,storeId);
	}

	@Override
	public boolean updateDetails(Integer orderId, Integer storeId, String status) throws JAXBException {
		
		return repo.updateDetails(orderId,storeId,status);
	}

	@Override
	public List<Item> searchById(Integer orderId) {
		return repo.searchById(orderId);
	}

	@Override
	public Item searchByname(String itemName) {
		return repo.searchByName(itemName);
	}

	@Override
	public List<Transaction> getAll() {
	    
	List<Transaction> transactions=	repo.getAll();
	
	Store store=new Store();
	store.setTransactions(transactions);
	 JAXBContext context;
	try {
		context = JAXBContext.newInstance(Store.class);
		Marshaller marshaller=context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(store,new File("Store.xml"));
	} catch (JAXBException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return transactions;
	}

}
