package com.project.controller;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.model.Item;

import com.project.model.Transaction;
import com.project.service.TransactionService;
import com.project.validation.XsdValidation;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController 
{
	
	@Autowired
	private TransactionService service;
	
    private  XsdValidation xmlValidation;
	
	@PostMapping("/add")
    public void addDetails() throws JAXBException
    {
    	
    	File file=new File("Store2.xml");
    	boolean isValid = xmlValidation.validateXMLSchema("validation.xsd",file);
        
        if(isValid){
           System.out.println(file+ " is valid against  validation.xsd");
           JAXBContext context=JAXBContext.newInstance(Transaction.class);
           Unmarshaller unmarshaller=context.createUnmarshaller();
           Transaction transaction= (Transaction) unmarshaller.unmarshal(file);
           service.addDetails(transaction);
           getAll();
        } else {
           System.out.println( file + " is not valid against validation.xsd");
        }
    	
    }
	@GetMapping("/getOrderDetails")
	public List<Item> getOrderDetails(@RequestParam("orderId")Integer orderId,@RequestParam("storeId")Integer storeId )
	{
	  List<Item> items= service.getOrderDetails(orderId,storeId);
	  return items;
	}
	
	@PutMapping("/updateDetails")
	public Boolean updateDetails(@RequestParam("orderId")Integer orderId,@RequestParam("storeId")Integer storeId,@RequestParam("status") String status ){
		
	Boolean res=false;
      boolean result;
	try {
		result = service.updateDetails(orderId,storeId,status);
		 if(result) {
			 res= true;
		}
	} catch (JAXBException e) {
		e.printStackTrace();
	}
	return res;
}
	
	@GetMapping("/getbyid")
	public  List<Item> searchById(@RequestParam("orderId") Integer orderId)
	{
		return service.searchById(orderId);
	}
	
	@GetMapping("/getbyName")
	public Item searchByItemName(@RequestParam("itemName") String itemName)
	{
		return service.searchByname(itemName);
	}
	

	@GetMapping("/getAll")
	public List<Transaction> getAll()
	{
	
		List<Transaction> transactions=null;;
		transactions=service.getAll();
		return transactions;
	}
	
}
