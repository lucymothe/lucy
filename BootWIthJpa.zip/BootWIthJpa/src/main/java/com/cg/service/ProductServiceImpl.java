package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Product;
import com.cg.dao.IProductRepo;
@Service
public class ProductServiceImpl implements IProductService{
	@Autowired
	private IProductRepo repo;

	@Override
	public List<Product> createProduct(Product product) {
		// TODO Auto-generated method stub
		repo.save(product);
		return  repo.findAll();
	}

	@Override
	public List<Product> getAllProducts() {
		return  repo.findAll();
	}

	@Override
	public Product updateProduct(Product product) {
		/*
		 * Product productFromDb=repo.findById(product.getProductId()).get();
		 * product.setProductName(product.getProductName()); product.
		 */
		repo.save(product);
		return product;
	}

	@Override
	public void delProduct(Integer productId) {
		repo.deleteById(productId);
	}

}
