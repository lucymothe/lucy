import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/app/home.component';
import { AboutComponent } from 'src/app/about.component';
import { ContactComponent } from 'src/app/contact.component';
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';
import { HelpComponent } from './help.component';
import { ResetPasswordComponent } from './reset-password.component';
import { ForgotPasswordComponent } from './forgot-password.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'help',component:HelpComponent},
  {path:'reset',component:ResetPasswordComponent},
  {path:'forgot',component:ForgotPasswordComponent},
  
  
  {path:'',redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
