import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DherbeService {

  constructor(private http:HttpClient) { }
  addData(model:any){
    let input={
      "userName":model.name,
      "mobileNum":model.phone,
      "gender":model.gender,
      "emailId":model.email,
      "address":model.address,
      "password":model.password,
      "conformPassword":model.cpassword,
      "role":model.roles,
      "securityQuestion":model.securityQuestion,
      "answer":model.answer
        
    }
     return this.http.post("http://localhost:9061/addDetails",input);
  }
}
