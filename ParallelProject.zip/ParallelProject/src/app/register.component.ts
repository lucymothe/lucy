import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators,FormControl} from '@angular/forms';
import { DherbeService } from './dherbe.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 userForm: FormGroup;

  model:any={};


  
  
  constructor(private formBuilder:FormBuilder,private service:DherbeService) {
   
   }

  ngOnInit() {
  }
  onSubmit(){
    console.log(this.userForm.value);
     this.service.addData(this.model).subscribe();

  }


}
