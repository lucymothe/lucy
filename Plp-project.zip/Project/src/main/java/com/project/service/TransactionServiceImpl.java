package com.project.service;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.TransactionDao;
import com.project.model.Item;

import com.project.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService{

	@Autowired
	private TransactionDao repo;
	
	@Override
	public void addDetails(Transaction transaction) throws JAXBException {
        repo.addDetails(transaction);		
	}

	@Override
	public List<Item> getOrderDetails(Integer orderId, Integer storeId) {
		
		return repo.getOrderDetails(orderId,storeId);
	}

	@Override
	public boolean updateDetails(Integer orderId, Integer storeId, String status) throws JAXBException {
		
		return repo.updateDetails(orderId,storeId,status);
	}

	@Override
	public List<Item> searchById(Integer orderId) {
		return repo.searchById(orderId);
	}

	@Override
	public Item searchByname(String itemName) {
		return repo.searchByName(itemName);
	}

}
