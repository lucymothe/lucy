package com.project.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@XmlRootElement
@Document(collection = "OrderDetails_441")
public class Transaction 
{
	@Id
    private Integer storeId;
	private List<TransactionDetails> transactionDetails;
	public Transaction() {
		super();
	}
	public Transaction(Integer storeId, List<TransactionDetails> transactionDetails) {
		super();
		this.storeId = storeId;
		this.transactionDetails = transactionDetails;
	}
	public Integer getStoreId() {
		return storeId;
	}
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
	public List<TransactionDetails> getTransactionDetails() {
		return transactionDetails;
	}
	public void setTransactionDetails(List<TransactionDetails> transactionDetails) {
		this.transactionDetails = transactionDetails;
	}
	@Override
	public String toString() {
		return "Transaction [storeId=" + storeId + ", transactionDetails=" + transactionDetails + "]";
	}
	
	
}
