package com.project.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;


public class Delivery {
	
	@XmlAttribute
	private String value1;
	private String status;

	public Delivery(String value1, String status) {
		super();
		this.value1 = value1;
		this.status = status;
	}

	public Delivery() {
		super();
	}

	public String getValue1() {
		return value1;
	}

	public void setValue(String value1) {
		this.value1 = value1;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Delivery [value=" + value1+ ", status=" + status + "]";
	}

}
