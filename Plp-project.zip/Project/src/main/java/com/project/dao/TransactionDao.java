package com.project.dao;

import java.util.List;

import javax.xml.bind.JAXBException;

import com.project.model.Item;

import com.project.model.Transaction;

public interface TransactionDao {



	List<Item> getOrderDetails(Integer orderId, Integer storeId);

	boolean updateDetails(Integer orderId, Integer storeId, String status) throws JAXBException;

	List<Item> searchById(Integer orderId);

	Item searchByName(String itemName);



	void addDetails(Transaction transaction) throws JAXBException;

}
