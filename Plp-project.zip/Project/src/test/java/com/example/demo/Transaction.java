package com.example.demo;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.controller.TransactionController;
import com.project.model.Item;
import com.project.validation.XsdValidation;

class Transaction {
	
	private  XsdValidation xmlValidation;
	

	TransactionController controller=new TransactionController();
    
	@Test
	void addFile() throws JAXBException 
	{
		File file=new File("demo1.xml");
         boolean isValid = xmlValidation.validateXMLSchema("validation.xsd",file);
        
        if(isValid){
           System.out.println(file+ " is valid against  validation.xsd");
        } else {
           System.out.println( file + " is not valid against validation.xsd");
        }
	}
	
	@Test
    void getDetails()
    {
    }
}
