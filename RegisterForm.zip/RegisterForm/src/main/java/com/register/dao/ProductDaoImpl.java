package com.register.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.register.model.Products;

@Repository
public class ProductDaoImpl implements ProductDao
{
	@Autowired
    MongoTemplate mongoTemplate;
	
	@Override
	public Products saveProduct(Products product) {
	     mongoTemplate.save(product);
	     return product;
	}

	@Override
	public List<Products> getProducts() {
		return mongoTemplate.findAll(Products.class);
	}

	@Override
	public List getProductByName(String prodName) {
		List<Products> prod1=new ArrayList<>();
	    List<Products> prod2=mongoTemplate.findAll(Products.class);
	    for(Products pro : prod2) {
	    if((pro.getProdName().replaceAll(" ","")).equalsIgnoreCase(prodName.replaceAll(" ","")))
	    	{
	    		prod1.add(pro);
	    	}
	    }
	   
		return prod1;
	}

	@Override
	public void deleteProduct(Integer id) {
       Query query=Query.query(Criteria.where("_id").is(id));
       mongoTemplate.remove(query,Products.class);
	}

	@Override
	public Products getById(Integer id) {
		 Query query=Query.query(Criteria.where("_id").is(id));
		return mongoTemplate.findOne(query,Products.class);
	}

	@Override
	public Boolean updateProduct(Products product,Integer id) 
	{
		Query query=Query.query(Criteria.where("_id").is(id));
		Products product1=mongoTemplate.findOne(query,Products.class);
		product1.setExpireDate(product.getExpireDate());
		product1.setWeight(product.getWeight());
		product1.setPrice(product.getPrice());
		product1.setStockStatus(product.getStockStatus());
		mongoTemplate.save(product1);
		
		if(product1.getPrice()==product.getPrice())
			return true;
		else
			return false;
	}

}



