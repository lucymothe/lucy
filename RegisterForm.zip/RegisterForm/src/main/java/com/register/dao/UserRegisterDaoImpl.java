package com.register.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.register.model.User;

@Repository
public class UserRegisterDaoImpl implements UserRegisterDao
{
	 User user,user1;
    @Autowired
	private MongoTemplate mongoTemplate;
	
    @Override
	public User addDetails(User user) 
    {
       mongoTemplate.save(user);
		return user;
	}
    

	@Override
	public User getMobileAndPassword(Long mobile,String password) 
	{
	    User user=mongoTemplate.findOne(Query.query(Criteria.where("mobileNum").is(mobile)),User.class);
	    if(user==null)
	    {
	    	return null;
	    }
	    else {
	    if(user.getPassword().equals(password))
	     	return user;
	    else
	    	return null;}
	}

	@Override
	public User checkUser(Long mobile, String question, String answer) 
	{
		 user=mongoTemplate.findOne(Query.query(Criteria.where("mobileNum").is(mobile)),User.class);
		 if(user.getSecurityQuestion().equals(question) && user.getAnswer().equals(answer))
		 {
				 return user;}
			 else {
				 return null; 
			 }
		
	}

	@Override
	public void reset(String password) {
		Long mob= user.getMobileNum();
		User user2=mongoTemplate.findOne(Query.query(Criteria.where("mobileNum").is(mob)),User.class);
		user2.setPassword(password);
		mongoTemplate.save(user2);
	}

	@Override
	public List<User> getUsers() {
		
	List<User> users=mongoTemplate.findAll(User.class);
	List<User> users1=new ArrayList<>();
	for(User user : users) {
		if(user.getRole().equals("User")) {
			users1.add(user);
		}
	}
	return users1;
	}

	@Override
	public void deleteUser(Long mobileNum) {
		User user2=mongoTemplate.findOne(Query.query(Criteria.where("mobileNum").is(mobileNum)),User.class);
		System.out.println(user2);
		mongoTemplate.remove(user2);
		
	}

	@Override
	public void updateUser(User user) {
		
		User user2=mongoTemplate.findOne(Query.query(Criteria.where("userName").is(user.getUserName())),User.class);
	    System.out.println(user2);
		user2.setMobileNum(user.getMobileNum());
		//user2.setPassword(user.getPassword());
		user2.setAddress(user.getAddress());
		System.out.println(user2);
		mongoTemplate.save(user2);
	}
	

}
