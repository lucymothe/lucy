package com.register.dao;

import java.util.List;

import com.register.model.Products;

public interface ProductDao {

	Products saveProduct(Products product);

	List<Products> getProducts();

	List getProductByName(String ProdName);

	void deleteProduct(Integer id);

	Products getById(Integer id);

	Boolean updateProduct(Products product,Integer id);

}
