package com.register.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "user_details2")
public class User {
	
	@Id
	private String userId;
	private String userName;
	private Long mobileNum;
	private String gender;
	private String emailId;
	private String address;
	private String password;
	private String conformPassword;
	private String role;
	private String securityQuestion;
	private String answer;

	public User() {
		super();
	}

	public User(String userId, String userName, Long mobileNum, String gender, String emailId, String address,
			String password, String role, String securityQuestion, String answer) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.mobileNum = mobileNum;
		this.gender = gender;
		this.emailId = emailId;
		this.address = address;
		this.password = password;
		//this.conformPassword = conformPassword;
		this.role = role;
		this.securityQuestion = securityQuestion;
		this.answer = answer;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(Long mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*
	 * public String getConformPassword() { return conformPassword; }
	 * 
	 * public void setConformPassword(String conformPassword) { this.conformPassword
	 * = conformPassword; }
	 */

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", mobileNum=" + mobileNum + ", gender=" + gender
				+ ", emailId=" + emailId + ", address=" + address + ", password=" + password  + ", role=" + role + ", securityQuestion=" + securityQuestion + ", answer=" + answer
				+ "]";
	}

}
