package com.register.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "product")
public class Products {

	@Id
	private Integer prodId;
	private String prodName;
	private String category;
	private String guidelines;
	private String stockStatus;
	private String weight;
	private String expireDate;
	private Double price;
	private String imageUrl;

	public Products() {
		super();
	}

	public Products(Integer prodId, String prodName, String category, String guidelines, String stockStatus,
			String weight, String expireDate, Double price, String imageUrl) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.category = category;
		this.guidelines = guidelines;
		this.stockStatus = stockStatus;
		this.weight = weight;
		this.expireDate = expireDate;
		this.price = price;
		this.imageUrl = imageUrl;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getGuidelines() {
		return guidelines;
	}

	public void setGuidelines(String guidelines) {
		this.guidelines = guidelines;
	}

	public String getStockStatus() {
		return stockStatus;
	}

	public void setStockStatus(String stockStatus) {
		this.stockStatus = stockStatus;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Products [prodId=" + prodId + ", prodName=" + prodName + ", category=" + category + ", guidelines="
				+ guidelines + ", stockStatus=" + stockStatus + ", weight=" + weight + ", expireDate=" + expireDate
				+ ", price=" + price + ", imageUrl=" + imageUrl + "]";
	}

	
}
