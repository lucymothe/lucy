package com.register.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.register.dao.UserRegisterDao;
import com.register.model.User;

@Service
public class UserRegisterServiceImpl implements UserRegisterService
{
    @Autowired
	private UserRegisterDao repo;
	
    @Override
	public User addDetails(User user) 
    {
    	return repo.addDetails(user);
	}

	@Override
	public User getMobileAndPassword(Long mobile, String password) {
		return repo.getMobileAndPassword(mobile,password);
	}

	@Override
	public User checkUser(Long mobile, String question, String answer) {
	
		return repo.checkUser(mobile,question,answer);
	}

	@Override
	public void reset(String password) {
		
		 repo.reset(password);
	}

	@Override
	public List<User> getUsers() {
		
		return repo.getUsers();
	}

	@Override
	public void deleteUser(Long mobileNum) {
	   System.out.println("service");
		repo.deleteUser(mobileNum);
	}

	@Override
	public void updateUser(User user) {
		repo.updateUser(user);
	}

}
