package com.register.service;

import java.util.List;

import com.register.model.User;

public interface UserRegisterService {

	User addDetails(User user);

	User getMobileAndPassword(Long mobile,String password);

	User checkUser(Long mobile, String question, String answer);

	void reset(String password);

	List<User> getUsers();

	void deleteUser(Long mobileNum);

	void updateUser(User user);

}
