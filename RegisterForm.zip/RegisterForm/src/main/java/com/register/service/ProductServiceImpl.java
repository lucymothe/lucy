package com.register.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.register.dao.ProductDao;
import com.register.model.Products;

@Service
public class ProductServiceImpl implements ProductService
{
    @Autowired
	private ProductDao repo;
	
	@Override
	public Products saveProduct(Products product) {
		return repo.saveProduct(product);
	}

	@Override
	public List<Products> getProducts(){
		return repo.getProducts();
	}

	@Override
	public List getProductByName(String prodName) {
		return repo.getProductByName(prodName);
	}

	@Override
	public void deleteProduct(Integer id) {
		repo.deleteProduct(id);
		
	}

	@Override
	public Products getById(Integer id) {
		return repo.getById(id);
	}

	@Override
	public Boolean updateProduct(Products product,Integer id) {
		return repo.updateProduct(product,id);
		
	}

}
