package com.register.service;

import java.util.List;

import com.register.model.Products;

public interface ProductService {

	Products saveProduct(Products product);

	List<Products> getProducts();

	List getProductByName(String searchterm);

	void deleteProduct(Integer id);

	Products getById(Integer id);

	Boolean updateProduct(Products product,Integer id);

}
