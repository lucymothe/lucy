package com.register.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.register.model.User;
import com.register.service.UserRegisterService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class RegisterController 
{
	@Autowired
	private UserRegisterService service;
	
    User user;
    @PostMapping("/addDetails")
	public String addDetails(@RequestBody User user)
	{
    	User user1=service.addDetails(user);
		System.out.println(user1);
		if(user1==null)
			return "Data cannot be added";
		else
			return "Registration successfull";
	}
    
    @GetMapping("/getUser")
    public ResponseEntity<Integer> getMobileAndPassword(@RequestParam("mobileNum") Long mobile,@RequestParam("password") String password)
    {
    	User user1=service.getMobileAndPassword(mobile,password);
      
        if(user1==null) {
      
        	return new ResponseEntity<Integer>(5,HttpStatus.OK);
        	
        }else {
        user=user1;
        String role=user1.getRole();
    	if(role.equals("User"))
    	   return new ResponseEntity<Integer>(1,HttpStatus.OK);
    	else if(role.equals("Admin"))
    		return new ResponseEntity<Integer>(-1,HttpStatus.OK);
    	else
    		return new ResponseEntity<Integer>(0,HttpStatus.OK);
        }
    }
    
    @GetMapping("/checkUser")
    public ResponseEntity<Boolean> checkUser(@RequestParam("mobileNum") Long mobile,@RequestParam("securityQuestion") String question, @RequestParam("answer") String answer)
    {
    	User user1=service.checkUser(mobile,question,answer);
    	if(user1==null)
    		return  new ResponseEntity(false,HttpStatus.NOT_FOUND);
    	else
    		return new ResponseEntity(true,HttpStatus.OK);
    }
    
    @PutMapping("/reset")
    public void reset(@RequestParam("password") String password)
    {
         service.reset(password);
    }
    
    @GetMapping("/getUsers")
	public ResponseEntity<List<User>> getUsers()
	{
		 List<User> userList=service.getUsers();
		if(userList==null) {
			return new ResponseEntity("No data found",HttpStatus.NOT_FOUND);
		}
	    return new ResponseEntity<List<User>>(userList,HttpStatus.OK);
	}
    
    @DeleteMapping("/deleteUser/{mobileNum}")
    public void deleteUser(@PathVariable("mobileNum") String mobileNum) {
    	Long mobileNum1=Long.parseLong(mobileNum);
    	 service.deleteUser(mobileNum1);
    }
    
    @GetMapping("/getByMobile")
    public ResponseEntity<User> getUser()
    {
    	return new ResponseEntity<User>(user,HttpStatus.OK);
    }
    
    @PutMapping("/updateUser")
    public ResponseEntity<String> updateUser(@RequestBody User user)
    {
    	System.out.println("update");
    	service.updateUser(user);
    	return new ResponseEntity<String>("hii",HttpStatus.OK);
    }
}
