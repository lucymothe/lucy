package com.register.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.register.model.Products;
import com.register.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController 
{
	@Autowired
    private ProductService service;
	
	Integer id;
	List<Products> productsList;
	
	@PostMapping("/upload")
	public ResponseEntity<List<Products>> saveProduct(@RequestParam("file") MultipartFile file1) throws IOException{
		
		String line,name="C:\\Users\\rnandamu\\Desktop\\"+file1.getOriginalFilename();
		FileReader fr=new FileReader(name);
		Products product1=new Products();
		System.out.println(name);
		BufferedReader br=new BufferedReader(fr);
	    while((line=br.readLine())!=null) { 
	    	Products product=new Products();
			
			System.out.println(line);
			String []data=line.split(",");
			product.setProdId(Integer.parseInt(data[0]));
			product.setProdName(data[1]);
			product.setCategory(data[2]);
			product.setGuidelines(data[3]);
			product.setStockStatus(data[4]);
			product.setWeight(data[5]);
			product.setExpireDate(data[6]);
			product.setPrice(Double.parseDouble(data[7]));
			product.setImageUrl(data[8]);
			product1=service.saveProduct(product);
		}
		if(product1!=null) {
		    return new ResponseEntity(productsList,HttpStatus.OK);}
		return new ResponseEntity(null,HttpStatus.NOT_FOUND);
	 }
	
	@GetMapping("/getProducts")
	public ResponseEntity<List<Products>> getProducts()
	{
		productsList=service.getProducts();
		if(productsList==null) {
			return new ResponseEntity("No data found",HttpStatus.NOT_FOUND);
		}
	    return new ResponseEntity<List<Products>>(productsList,HttpStatus.OK);
	}
	
	@GetMapping("/getProductByName")
	public ResponseEntity<List<Products>> getProductByName(@RequestParam("productName") String prodName)
	{
	  System.out.println("controller");	
	  List	productList=service.getProductByName(prodName);
		if(productList==null) {
			return new ResponseEntity("No data found",HttpStatus.NOT_FOUND);
		}
	    return new ResponseEntity<List<Products>>(productList,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete")
    public void deleteProd(@RequestParam("id") Integer id) {
		 System.out.println("welcome");
       //  Integer id1=Integer.parseInt(id);
    	 service.deleteProduct(id);
    }
	 
	@GetMapping("/getbyid")
	public ResponseEntity getById(@RequestParam("pid") Integer id)
	{
		this.id=id;
		Products product=service.getById(id);
		if(product==null)
		{
			return new ResponseEntity("unable to get data",HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity(product,HttpStatus.OK);
		}
	}
	
	@PutMapping("/update")
	public ResponseEntity updateProduct(@RequestBody Products product)
	{
		Boolean res=service.updateProduct(product,id);
		if(res==true)
			return new ResponseEntity("Updated successfully",HttpStatus.OK);
		else
			return new ResponseEntity("cannot updated",HttpStatus.NOT_FOUND);
	}
}
