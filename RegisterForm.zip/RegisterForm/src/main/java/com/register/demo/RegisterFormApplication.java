package com.register.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

import com.register.controller.ProductController;

@SpringBootApplication
@ComponentScan("com.register")
public class RegisterFormApplication {

	private static final Logger LOGGER = LogManager.getLogger(RegisterFormApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(RegisterFormApplication.class, args);
		System.out.println("welcome");
		LOGGER.info("Info message");
		LOGGER.debug("Debug level log message");
		LOGGER.fatal("This is a fatal message");
		LOGGER.error("Error level log message");
		LOGGER.warn("This is a warn message");
	}

}
